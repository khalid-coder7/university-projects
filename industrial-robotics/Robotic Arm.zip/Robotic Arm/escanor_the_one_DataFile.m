% Simscape(TM) Multibody(TM) version: 7.3

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(17).translation = [0.0 0.0 0.0];
smiData.RigidTransform(17).angle = 0.0;
smiData.RigidTransform(17).axis = [0.0 0.0 0.0];
smiData.RigidTransform(17).ID = '';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [0 102 0];  % mm
smiData.RigidTransform(1).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(1).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(1).ID = 'B[base-2:-:Part2-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [0 20.000000000000014 0];  % mm
smiData.RigidTransform(2).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(2).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(2).ID = 'F[base-2:-:Part2-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [0 160 149.98614259076263];  % mm
smiData.RigidTransform(3).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(3).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(3).ID = 'B[Part2-1:-:Part3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [-350.00000000005616 -20.000000000000568 -1.9387158545214334e-11];  % mm
smiData.RigidTransform(4).angle = 2.094395102393193;  % rad
smiData.RigidTransform(4).axis = [0.57735026918962484 -0.57735026918962684 0.57735026918962562];
smiData.RigidTransform(4).ID = 'F[Part2-1:-:Part3-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [0 -20 0];  % mm
smiData.RigidTransform(5).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(5).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(5).ID = 'B[Part3-1:-:Part4-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [-28.000000000000199 -45.000000000094737 50.000000000049027];  % mm
smiData.RigidTransform(6).angle = 2.0943951023931962;  % rad
smiData.RigidTransform(6).axis = [0.57735026918962595 0.57735026918962595 0.57735026918962529];
smiData.RigidTransform(6).ID = 'F[Part3-1:-:Part4-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [0 0 276.00000000000006];  % mm
smiData.RigidTransform(7).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(7).axis = [1 0 0];
smiData.RigidTransform(7).ID = 'B[Part4-1:-:Part5-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [-1.7976731214730535e-12 1.0373923942097463e-12 -19.999999999998963];  % mm
smiData.RigidTransform(8).angle = 3.1415926535897913;  % rad
smiData.RigidTransform(8).axis = [1 1.2465601812714781e-30 1.2864417904905466e-15];
smiData.RigidTransform(8).ID = 'F[Part4-1:-:Part5-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [12.499999999999956 0 109.99999999999987];  % mm
smiData.RigidTransform(9).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(9).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(9).ID = 'B[Part5-1:-:Part6-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(10).translation = [9.9999999999999289 42.000000000000114 -2.8421709430404007e-14];  % mm
smiData.RigidTransform(10).angle = 2.0943951023931962;  % rad
smiData.RigidTransform(10).axis = [0.57735026918962518 0.57735026918962595 0.57735026918962618];
smiData.RigidTransform(10).ID = 'F[Part5-1:-:Part6-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(11).translation = [0 -71.700000000000102 0];  % mm
smiData.RigidTransform(11).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(11).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(11).ID = 'B[Part6-1:-:Part7-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(12).translation = [-1.723066134218243e-12 -2.1316282072803006e-14 19.99999999999951];  % mm
smiData.RigidTransform(12).angle = 1.1866928732135989e-15;  % rad
smiData.RigidTransform(12).axis = [-0.77349486420326519 0.63380256787991351 -2.9088395561838198e-16];
smiData.RigidTransform(12).ID = 'F[Part6-1:-:Part7-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(13).translation = [41.468239253257991 8.9999999999999947 33.444796065307038];  % mm
smiData.RigidTransform(13).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(13).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(13).ID = 'B[Part7-1:-:Part8-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(14).translation = [-28.589245159687408 59.452502143616812 -8.8817841970012523e-16];  % mm
smiData.RigidTransform(14).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(14).axis = [-1 6.9854603912081631e-33 -5.2304801316954318e-16];
smiData.RigidTransform(14).ID = 'F[Part7-1:-:Part8-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(15).translation = [-41.468239253258041 -8.9999999999999947 33.444796065306925];  % mm
smiData.RigidTransform(15).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(15).axis = [0.57735026918962584 -0.57735026918962573 0.57735026918962573];
smiData.RigidTransform(15).ID = 'B[Part7-1:-:Part8-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(16).translation = [-28.589245159687458 59.452502143616968 2.8421709430404007e-14];  % mm
smiData.RigidTransform(16).angle = 3.1415926535897927;  % rad
smiData.RigidTransform(16).axis = [-1 1.2464939889371798e-31 -4.7310753289481489e-16];
smiData.RigidTransform(16).ID = 'F[Part7-1:-:Part8-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(17).translation = [0 0 0];  % mm
smiData.RigidTransform(17).angle = 0;  % rad
smiData.RigidTransform(17).axis = [0 0 0];
smiData.RigidTransform(17).ID = 'RootGround[base-2]';


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(8).mass = 0.0;
smiData.Solid(8).CoM = [0.0 0.0 0.0];
smiData.Solid(8).MoI = [0.0 0.0 0.0];
smiData.Solid(8).PoI = [0.0 0.0 0.0];
smiData.Solid(8).color = [0.0 0.0 0.0];
smiData.Solid(8).opacity = 0.0;
smiData.Solid(8).ID = '';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 1.4748774710785859;  % kg
smiData.Solid(1).CoM = [-1.6103661707053027 -5.6614058297148402 96.226692739964477];  % mm
smiData.Solid(1).MoI = [9028.9168920522934 8626.8736712175905 1955.4457570590682];  % kg*mm^2
smiData.Solid(1).PoI = [-385.98679948238077 -109.79211661366189 -125.36747016014189];  % kg*mm^2
smiData.Solid(1).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = 'Part4*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 0.065803187103433677;  % kg
smiData.Solid(2).CoM = [0 0 17.838144466375727];  % mm
smiData.Solid(2).MoI = [32.197961273466319 38.874906038284387 39.080552595928175];  % kg*mm^2
smiData.Solid(2).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(2).color = [0.67843137254901964 0.67843137254901964 0.67843137254901964];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = 'Part7*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 0.35448013031302295;  % kg
smiData.Solid(3).CoM = [0 -15.227070510956739 0];  % mm
smiData.Solid(3).MoI = [436.32699967577321 242.68029327988228 442.79102170293629];  % kg*mm^2
smiData.Solid(3).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(3).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = 'Part6*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 0.046782470338330703;  % kg
smiData.Solid(4).CoM = [-5.0085407430074191 9.2463634224486757 9];  % mm
smiData.Solid(4).MoI = [46.38986305775115 11.247610709633841 55.054065518385883];  % kg*mm^2
smiData.Solid(4).PoI = [0 0 15.249753154796315];  % kg*mm^2
smiData.Solid(4).color = [0.69803921568627447 0 0];
smiData.Solid(4).opacity = 1;
smiData.Solid(4).ID = 'Part8*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(5).mass = 0.50092087622879833;  % kg
smiData.Solid(5).CoM = [-1.7859783552892643e-05 -2.0583853061922095e-06 66.889302919787426];  % mm
smiData.Solid(5).MoI = [1147.7090947006329 1279.4361337463024 478.80131982744052];  % kg*mm^2
smiData.Solid(5).PoI = [-1.7001579841949358e-06 0.00048743444059401182 4.2060930909760139e-05];  % kg*mm^2
smiData.Solid(5).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(5).opacity = 1;
smiData.Solid(5).ID = 'Part5*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(6).mass = 2.3885481449771171;  % kg
smiData.Solid(6).CoM = [3.8602636748199002 84.728579417308779 58.966795351070495];  % mm
smiData.Solid(6).MoI = [24615.892310683663 16805.379221067797 12377.010505190623];  % kg*mm^2
smiData.Solid(6).PoI = [-9416.9759531316104 -602.07586317212122 -542.91032636005934];  % kg*mm^2
smiData.Solid(6).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(6).opacity = 1;
smiData.Solid(6).ID = 'Part2*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(7).mass = 7.4888516925243129;  % kg
smiData.Solid(7).CoM = [-149.94260403624378 16.186626778321383 9.4468827900797852];  % mm
smiData.Solid(7).MoI = [4913.6665633264065 136976.47865493753 134186.63171434143];  % kg*mm^2
smiData.Solid(7).PoI = [148.9533244696035 1695.763291287758 -104.93819386764993];  % kg*mm^2
smiData.Solid(7).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(7).opacity = 1;
smiData.Solid(7).ID = 'Part3*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(8).mass = 5.6940330872396778;  % kg
smiData.Solid(8).CoM = [1.6532733693358164 38.166817268263593 -1.6417382351717069];  % mm
smiData.Solid(8).MoI = [36095.717389647529 66098.733893998447 36083.300061165282];  % kg*mm^2
smiData.Solid(8).PoI = [53.306386273198974 -900.35917562049792 -50.015446432934574];  % kg*mm^2
smiData.Solid(8).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(8).opacity = 1;
smiData.Solid(8).ID = 'base*:*Default';


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(8).Rz.Pos = 0.0;
smiData.RevoluteJoint(8).ID = '';

smiData.RevoluteJoint(1).Rz.Pos = 93.458614327243438;  % deg
smiData.RevoluteJoint(1).ID = '[base-2:-:Part2-1]';

smiData.RevoluteJoint(2).Rz.Pos = -167.23350715860221;  % deg
smiData.RevoluteJoint(2).ID = '[Part2-1:-:Part3-1]';

smiData.RevoluteJoint(3).Rz.Pos = 176.0651390620063;  % deg
smiData.RevoluteJoint(3).ID = '[Part3-1:-:Part4-1]';

smiData.RevoluteJoint(4).Rz.Pos = -126.6655103570544;  % deg
smiData.RevoluteJoint(4).ID = '[Part4-1:-:Part5-1]';

smiData.RevoluteJoint(5).Rz.Pos = -92.267653628331075;  % deg
smiData.RevoluteJoint(5).ID = '[Part5-1:-:Part6-1]';

smiData.RevoluteJoint(6).Rz.Pos = 57.093863542144547;  % deg
smiData.RevoluteJoint(6).ID = '[Part6-1:-:Part7-1]';

smiData.RevoluteJoint(7).Rz.Pos = -34.995868320061149;  % deg
smiData.RevoluteJoint(7).ID = '[Part7-1:-:Part8-3]';

smiData.RevoluteJoint(8).Rz.Pos = -67.658784231030182;  % deg
smiData.RevoluteJoint(8).ID = '[Part7-1:-:Part8-5]';

